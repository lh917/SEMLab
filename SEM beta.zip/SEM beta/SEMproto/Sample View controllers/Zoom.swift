//
//  Zoom.swift
//  SEMproto
//
//  Created by Emyr  on 04/08/2020.
//  Copyright © 2020 Emyr . All rights reserved.
//

import Foundation

class Zoom {
    
    var labelText = ""
    var isLit = false
}
