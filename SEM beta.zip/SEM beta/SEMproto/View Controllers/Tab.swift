//
//  mainMenuTab.swift
//  SEMproto
//
//  Created by Han on 2020/7/27.
//  Copyright © 2020 Emyr . All rights reserved.
//

import Foundation

// This file contains the class for the main menu tabs

class Tab: Decodable {
    
    var imageName = ""
    // JSON key words
    var sampleName:String?
    var sampleNumber:Int?
    var textTitle:String?
    var sampleText:String?
    
    
    
    
    
}
